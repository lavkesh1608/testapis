<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Messages extends CI_Model {

	public function  create(){

	}

	public function  list(){

	}

	

}

?>