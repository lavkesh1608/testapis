<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Users extends CI_Model {


	function __construct()
	{
        // Call the Model constructor
		parent::__construct();
		$this->load->database();
	}


	public function create($user){

		//print_r(expression)

		$this->db->insert("users",$user);
		$id = $this->db->insert_id();
		$q = $this->db->get_where('users', array('userId' => $id));
		return $q->row();

		//return $user;

	}

	public function  login($mobileNo){

		/*$this->db->select("users",$user);
		$id = $this->db->insert_id();
		$q = $this->db->get_where('users', array('userId' => $id));
		return $q->row();*/

		$data=array('isOnline'=>1);
		$where=array('phoneNumber'=>$mobileNo);


		$this->db->update('users', $data, $where);

		$q = $this->db->get_where('users', array('phoneNumber' => $mobileNo));
		return $q->row();

	}

	public function  logout(){

	}

}

?>