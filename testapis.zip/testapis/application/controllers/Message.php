<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Message extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


	public function __construct() {
		parent::__construct();
		$this->load->model('users');

	}


	public function index()
	{
		//$this->load->view('welcome_message');
	}

	public function send(){

		$responseData=array();

		$requiredArray=array();

		if(!isset($_POST['firstName']))
			array_push($requiredArray,'Firstname required.' );

		if(!isset($_POST['lastName']))
			array_push($requiredArray,'Lastname required.' );

		if(!isset($_POST['email']))
			array_push($requiredArray,'Email required.' );

		if(!isset($_POST['phoneNumber']))
			array_push($requiredArray,'Phone number required.' );


		if(count($requiredArray)>0){
			$responseData['message']='Validation error';
			$responseData['requiredFields']=$requiredArray;
			echo json_encode($responseData);
			exit();

		}

		$firstName = $_POST['firstName'];
		$lastName = $_POST['lastName'];
		$email = $_POST['email'];
		$phoneNumber = $_POST['phoneNumber'];	//var firstName = $_POST['firstName'];


		$user=array('firstName'=>$firstName,
			'lastName'=>$lastName,
			'email'=>$email,
			'phoneNumber'=>$phoneNumber);

		$response=$this->users->create($user);

		if($response){

			$responseData['status']='success';
			$responseData['data']=$response;
			echo json_encode($responseData);

		}else{

			$responseData['status']='failure';
			//$responseData['data']=$response;
			echo json_encode($responseData);

		}



		
	}	


	public function login(){

		$responseData=array();

		if(isset($_POST['phoneNumber'])){


			$response=$this->users->login($_POST['phoneNumber']);

			if($response){

				$responseData['status']='success';
				$responseData['data']=$response;
				echo json_encode($responseData);

			}else{
				$responseData['status']='failure';
			//$responseData['data']=$response;
				echo json_encode($responseData);

			}

			

		}else{

			echo json_encode(array('status'=>'failure',
				'message'=>'Validation error',
				"requiredFields"=>array('Phone number required.')
				));

		}
		
		
	}


	public function get(){
		
	}

	
}
